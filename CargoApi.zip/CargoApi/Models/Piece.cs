﻿using System;
using System.Collections.Generic;

namespace CargoApi.Models
{
    public partial class Piece
    {
        public int Id { get; set; }
        public int? Qnty { get; set; }
        public string? ShptNmbr { get; set; }

        public virtual Shipment? ShptNmbrNavigation { get; set; }
    }
}
