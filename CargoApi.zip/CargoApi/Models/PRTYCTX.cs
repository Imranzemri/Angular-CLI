﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CargoApi.Models
{
    public partial class PRTYCTX : DbContext
    {
        public PRTYCTX()
        {
        }

        public PRTYCTX(DbContextOptions<PRTYCTX> options)
            : base(options)
        {
        }

        public virtual DbSet<Client> Clients { get; set; } = null!;
        public virtual DbSet<Piece> Pieces { get; set; } = null!;
        public virtual DbSet<Project> Projects { get; set; } = null!;
        public virtual DbSet<Receipt> Receipts { get; set; } = null!;
        public virtual DbSet<Role> Roles { get; set; } = null!;
        public virtual DbSet<Shipment> Shipments { get; set; } = null!;
        public virtual DbSet<TimeSheet> TimeSheets { get; set; } = null!;
        public virtual DbSet<User> Users { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("MyDatabaseConnection");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Client>(entity =>
            {
                entity.ToTable("Client");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("ID");

                entity.Property(e => e.Address).HasMaxLength(100);

                entity.Property(e => e.Name).HasMaxLength(50);
            });

            modelBuilder.Entity<Piece>(entity =>
            {
                entity.ToTable("PIECES");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Qnty).HasColumnName("QNTY");

                entity.Property(e => e.ShptNmbr)
                    .HasMaxLength(255)
                    .HasColumnName("SHPT_NMBR");

                entity.HasOne(d => d.ShptNmbrNavigation)
                    .WithMany(p => p.Pieces)
                    .HasPrincipalKey(p => p.ShptNmbr)
                    .HasForeignKey(d => d.ShptNmbr)
                    .HasConstraintName("FK__PIECES__SHPT_NMB__4CA06362");
            });

            modelBuilder.Entity<Project>(entity =>
            {
                entity.ToTable("Project");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("ID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.Description).HasMaxLength(100);

                entity.Property(e => e.Name).HasMaxLength(50);

                entity.HasOne(d => d.Client)
                    .WithMany(p => p.Projects)
                    .HasForeignKey(d => d.ClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Project_Client");
            });

            modelBuilder.Entity<Receipt>(entity =>
            {
                entity.ToTable("RECEIPT");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.RcptNmbr)
                    .HasMaxLength(255)
                    .HasColumnName("RCPT_NMBR");

                entity.Property(e => e.ShptNmbr)
                    .HasMaxLength(255)
                    .HasColumnName("SHPT_NMBR");

                entity.HasOne(d => d.ShptNmbrNavigation)
                    .WithMany(p => p.Receipts)
                    .HasPrincipalKey(p => p.ShptNmbr)
                    .HasForeignKey(d => d.ShptNmbr)
                    .HasConstraintName("FK__RECEIPT__SHPT_NM__4F7CD00D");
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.ToTable("Role");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("ID");

                entity.Property(e => e.Name).HasMaxLength(50);
            });

            modelBuilder.Entity<Shipment>(entity =>
            {
                entity.ToTable("SHIPMENT");

                entity.HasIndex(e => e.ShptNmbr, "UQ__SHIPMENT__5E9EFC15787C32BD")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CstmRpnt).HasColumnName("CSTM_RPNT");

                entity.Property(e => e.Dmnsn)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("DMNSN");

                entity.Property(e => e.Imgs).HasColumnName("IMGS");

                entity.Property(e => e.Locn)
                    .HasMaxLength(255)
                    .HasColumnName("LOCN");

                entity.Property(e => e.Name)
                    .HasMaxLength(255)
                    .HasColumnName("NAME");

                entity.Property(e => e.Note).HasColumnName("NOTE");

                entity.Property(e => e.Rpnt).HasColumnName("RPNT");

                entity.Property(e => e.ShptNmbr)
                    .HasMaxLength(255)
                    .HasColumnName("SHPT_NMBR");

                entity.Property(e => e.Wght)
                    .HasColumnType("decimal(10, 2)")
                    .HasColumnName("WGHT");
            });

            modelBuilder.Entity<TimeSheet>(entity =>
            {
                entity.ToTable("TimeSheet");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("ID");

                entity.Property(e => e.Date).HasColumnType("date");

                entity.Property(e => e.ProjectId).HasColumnName("ProjectID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.HasOne(d => d.Project)
                    .WithMany(p => p.TimeSheets)
                    .HasForeignKey(d => d.ProjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_TimeSheet_Project");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.TimeSheets)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_TimeSheet_User");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("User");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("ID");

                entity.Property(e => e.Email).HasMaxLength(50);

                entity.Property(e => e.Name).HasMaxLength(50);

                entity.Property(e => e.Password).HasMaxLength(50);

                entity.Property(e => e.RoleId).HasColumnName("RoleID");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_User_Role");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
