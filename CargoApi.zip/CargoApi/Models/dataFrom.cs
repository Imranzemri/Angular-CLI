﻿namespace CargoApi.Models
{
   
        public class dataFrom
        {
            public string Name { get; set; }
            public int ShipmentNo { get; set; }
            public int Piece { get; set; }
            public decimal Dimension { get; set; }
            public decimal Weight { get; set; }
            public string Location { get; set; }
            public string Note { get; set; }
            public string[] Images { get; set; }
            public string Email { get; set; }
            //public string  CustomRecipient { get; set; }
        }
    

}
