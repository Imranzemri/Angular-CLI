﻿using System;
using System.Collections.Generic;

namespace CargoApi.Models
{
    public partial class Project
    {
        public Project()
        {
            TimeSheets = new HashSet<TimeSheet>();
        }

        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public string Description { get; set; } = null!;
        public int ClientId { get; set; }

        public virtual Client Client { get; set; } = null!;
        public virtual ICollection<TimeSheet> TimeSheets { get; set; }
    }
}
